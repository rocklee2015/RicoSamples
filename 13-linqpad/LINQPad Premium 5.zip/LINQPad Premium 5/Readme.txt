How to install?:
Disconnect from internet (Must)
Unpack and install LINQPad 5
Now run as admin the Activator
And then click on "Start Server"
Run LINQPad and activate/upgrade
Change Proxy to manual specify Proxy#
#Port address: http://127.0.0.1
#Proxy Port: 8080 and click "OK"
Enter any activation code eg: "MASTER"
Never change the proxy and never update
Pass: www.masterkreatif.com